/**
 * Onboarding Router — wizard + live company search.
 * 
 * NEW: When user enters company name, system searches web for info
 * and auto-fills industry, market, and provides company context.
 */
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { checkEditor } from "../_core/authorization";
import { z } from "zod";
import { logger } from "../_core/logger";
import { createOnboardingSession, getOnboardingSessionById, getOnboardingSessions, updateOnboardingSession } from "../db";
import { liveResearch } from "../liveIntelligence";
import { resilientLLM } from "../_core/llmRouter";
import { searchGoogle } from "../researchEngine";

export const onboardingRouter = router({
  create: protectedProcedure.input(z.object({
    companyName: z.string().max(255).optional(), contactName: z.string().max(255).optional(),
    email: z.string().email().max(320).optional(), phone: z.string().max(50).optional(),
    market: z.enum(["ksa", "egypt", "uae", "other"]).optional(), industry: z.string().max(255).optional(),
    website: z.string().max(500).optional(),
  })).mutation(async ({ input, ctx }) => createOnboardingSession(input)),
    checkEditor(ctx);

  getById: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => getOnboardingSessionById(input.id)),
  list: protectedProcedure.query(async () => getOnboardingSessions()),

  update: protectedProcedure.input(z.object({
    id: z.number(),
    step: z.enum(["company_info", "needs_assessment", "service_recommendation", "proposal_review", "contract"]).optional(),
    status: z.enum(["in_progress", "completed", "abandoned"]).optional(),
    assessmentAnswers: z.any().optional(),
    recommendedService: z.string().max(100).optional(),
    recommendationReason: z.string().max(5000).optional(),
  })).mutation(async ({ input, ctx }) => {
    checkEditor(ctx);
    const { id, ...data } = input;
    await updateOnboardingSession(id, data);
    return { success: true };
  }),

  submit: publicProcedure.input(z.object({
    companyName: z.string().min(1).max(255),
    contactName: z.string().max(255).optional(),
    email: z.string().email().max(320),
    phone: z.string().max(50).optional(),
    market: z.enum(["ksa", "egypt", "uae", "other"]).default("egypt"),
    industry: z.string().max(255).optional(),
    website: z.string().max(500).optional(),
    answers: z.any().optional(),
  })).mutation(async ({ input, ctx }) => createOnboardingSession({
    checkEditor(ctx);
    ...input, step: 'needs_assessment', status: 'in_progress', assessmentAnswers: input.answers,
  })),

  /** NEW: Search for a company and auto-fill details */
  lookupCompany: protectedProcedure
    .input(z.object({
      companyName: z.string().min(2).max(255),
      market: z.enum(["ksa", "egypt", "uae", "other"]).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      checkEditor(ctx);
      try {
        // Search for the company
        const query = `${input.companyName} ${input.market === 'ksa' ? 'Saudi Arabia' : input.market === 'egypt' ? 'Egypt' : ''} company`;
        const searchResults = await searchGoogle(query, 5);

        if (searchResults.length === 0) {
          return { found: false, suggestions: null };
        }

        // Use AI to extract structured company info from search results
        const searchContext = searchResults.map(r => `${r.title}: ${r.snippet}`).join('\n');

        const response = await resilientLLM({
          messages: [
            {
              role: 'system',
              content: 'You extract company information from search results. Return ONLY valid JSON. If info is not available, use null.',
            },
            {
              role: 'user',
              content: `Company name: "${input.companyName}"
Market: ${input.market || 'Unknown'}

Search results:
${searchContext}

Extract this JSON:
{
  "companyName": "Official company name",
  "industry": "Main industry (e.g., F&B, Healthcare, Tech, Retail, Education, Beauty, Real Estate)",
  "description": "One sentence description of what they do",
  "website": "Main website URL or null",
  "socialMedia": { "instagram": "handle or null", "linkedin": "URL or null" },
  "competitors": ["competitor1", "competitor2", "competitor3"],
  "estimatedSize": "startup | sme | midmarket | enterprise",
  "confidence": "high | medium | low"
}`,
            },
          ],
        }, { context: 'chat' });

        const parsed = JSON.parse(response.choices[0].message.content as string);
        logger.info({ company: input.companyName, found: true, confidence: parsed.confidence }, 'Company lookup completed');

        return { found: true, ...parsed, searchResults: searchResults.slice(0, 3).map(r => ({ title: r.title, url: r.url })) };
      } catch (err) {
        logger.debug({ err, company: input.companyName }, 'Company lookup failed');
        return { found: false, suggestions: null };
      }
    }),

  /** Seed demo data for first-time users */
  seedDemo: protectedProcedure.mutation(async ({ ctx }) => {
    checkEditor(ctx);
    const { seedDemoData } = await import('../demoData');
    const db = await import('../db');
    const seeded = await seedDemoData(
      db.createClient,
      db.createProject,
      db.createNote,
      db.createKnowledgeEntry,
      db.getClients,
    );
    return { seeded };
  }),

  /** Get onboarding tour steps */
  tourSteps: publicProcedure.query(() => {
    const { ONBOARDING_STEPS } = require('../demoData');
    return ONBOARDING_STEPS;
  }),
});
