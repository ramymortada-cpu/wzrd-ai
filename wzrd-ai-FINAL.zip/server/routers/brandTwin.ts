/** Brand Twin Router — health audits, alerts, metrics + OBSERVATORY. */
import { protectedProcedure, router } from "../_core/trpc";
import { checkEditor } from "../_core/authorization";
import { z } from "zod";
import { logger } from "../_core/logger";
import { runBrandAudit, compareSnapshots } from "../brandTwin";
import { createBrandHealthSnapshot, getLatestSnapshot, getSnapshotHistory, getSnapshotById, createBrandAlert, getAlertsByClient, updateAlertStatus, createBrandMetrics, getMetricsByClient, getBrandTwinDashboard } from "../db";
import { observeClient, observeAllClients } from "../brandObservatory";

export const brandTwinRouter = router({
  dashboard: protectedProcedure.query(async () => getBrandTwinDashboard()),

  runAudit: protectedProcedure.input(z.object({ clientId: z.number(), companyName: z.string().max(255), industry: z.string().max(255), market: z.string().max(100), website: z.string().max(500).optional() }))
    .mutation(async ({ input, ctx }) => {
      checkEditor(ctx);
      const result = await runBrandAudit(input);
      if (result) {
        const snapshotId = await createBrandHealthSnapshot({ ...result, clientId: input.clientId });
        logger.info({ clientId: input.clientId, score: result.overallScore }, 'Brand audit completed');
        return { snapshotId, ...result };
      }
      throw new Error('Brand audit failed');
    }),

  latestSnapshot: protectedProcedure.input(z.object({ clientId: z.number().int().positive() })).query(async ({ input }) => getLatestSnapshot(input.clientId)),
  history: protectedProcedure.input(z.object({ clientId: z.number().int().positive(), limit: z.number().max(50).default(20) })).query(async ({ input }) => getSnapshotHistory(input.clientId, input.limit)),
  snapshot: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => getSnapshotById(input.id)),

  compare: protectedProcedure.input(z.object({ snapshotIdA: z.number(), snapshotIdB: z.number() })).query(async ({ input }) => {
    const a = await getSnapshotById(input.snapshotIdA); const b = await getSnapshotById(input.snapshotIdB);
    if (!a || !b) throw new Error('Snapshots not found');
    return compareSnapshots(a, b);
  }),

  alerts: protectedProcedure.input(z.object({ clientId: z.number().int().positive(), status: z.string().max(50).optional() })).query(async ({ input }) => getAlertsByClient(input.clientId, input.status)),
  updateAlert: protectedProcedure.input(z.object({ id: z.number(), status: z.enum(["active", "acknowledged", "resolved", "dismissed"]) })).mutation(async ({ input, ctx }) => { await updateAlertStatus(input.id, input.status); return { success: true }; }),
    checkEditor(ctx);
  metrics: protectedProcedure.input(z.object({ clientId: z.number().int().positive(), dimension: z.string().max(100).optional() })).query(async ({ input }) => getMetricsByClient(input.clientId, input.dimension)),

  /** Observatory: scan a single client for brand signals */
  observe: protectedProcedure
    .input(z.object({ clientId: z.number().int().positive() }))
    .mutation(async ({ input, ctx }) => observeClient(input.clientId)),
      checkEditor(ctx);

  /** Observatory: scan ALL active clients */
  observeAll: protectedProcedure.mutation(async ({ ctx }) => observeAllClients()),
    checkEditor(ctx);
});
