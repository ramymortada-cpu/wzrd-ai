/**
 * Proposals Router — generate, send, track proposals.
 */
import { protectedProcedure, router } from "../_core/trpc";
import { checkEditor } from "../_core/authorization";
import { checkEditor } from "../_core/authorization";
import { z } from "zod";
import { sanitizeObject } from "../_core/sanitize";
import { audit } from "../_core/audit";
import { logger } from "../_core/logger";
import { resilientLLM } from "../_core/llmRouter";
import { createProposalInput } from "@shared/validators";
import { SERVICE_LABELS, SERVICE_PRICES } from "@shared/const";
import { buildSystemPrompt } from "../knowledgeBase";
import { notifyOwner } from "../_core/notification";
import {
  createProposal, getProposals, getProposalById, getProposalsByClient, updateProposal, deleteProposal,
  getClientById, createProposalAcceptance, getProposalAcceptances,
} from "../db";

export const proposalsRouter = router({
  list: protectedProcedure.query(async () => getProposals()),
  getById: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => getProposalById(input.id)),
  getByClient: protectedProcedure.input(z.object({ clientId: z.number().int().positive() })).query(async ({ input }) => getProposalsByClient(input.clientId)),

  create: protectedProcedure.input(createProposalInput).mutation(async ({ input, ctx }) => {
    checkEditor(ctx);
    const sanitized = sanitizeObject(input);
    const result = await createProposal(sanitized);
    const id = (result as string).id;
    if (id) await audit('proposals', id, 'create', ctx.user?.id);
    return result;
  }),

  generateWithAI: protectedProcedure
    .input(z.object({
      clientId: z.number(), serviceType: z.enum(["business_health_check", "starting_business_logic", "brand_identity", "business_takeoff", "consultation"]),
      language: z.enum(["en", "ar"]).default("en"), clientContext: z.string().max(10000).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      checkEditor(ctx);
      const client = await getClientById(input.clientId);
      const systemPrompt = buildSystemPrompt({ mode: 'proposal', serviceType: input.serviceType, clientContext: input.clientContext });
      const price = SERVICE_PRICES[input.serviceType];
      const userPrompt = `Generate a professional proposal for:\nClient: ${client?.companyName || client?.name || 'Unknown'}\nService: ${SERVICE_LABELS[input.serviceType]}\nPrice: ${price.toLocaleString()} EGP\nLanguage: ${input.language === 'ar' ? 'Arabic' : 'English'}\n${input.clientContext ? `Context: ${input.clientContext}` : ''}`;
      
      const response = await resilientLLM({ messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }] });
      const content = response.choices[0].message.content as string;
      
      const proposal = await createProposal({
        clientId: input.clientId, serviceType: input.serviceType, language: input.language,
        title: `${SERVICE_LABELS[input.serviceType]} — ${client?.companyName || client?.name || 'Client'}`,
        executiveSummary: content, price: String(price), currency: 'EGP', status: 'draft',
      }, { context: 'proposal' });
      logger.info({ proposalId: (proposal as string).id, service: input.serviceType }, 'AI-generated proposal');
      return proposal;
    }),

  update: protectedProcedure
    .input(z.object({ id: z.number(), status: z.enum(["draft", "sent", "accepted", "rejected"]).optional(), title: z.string().max(500).optional(), executiveSummary: z.string().max(50000).optional(), price: z.string().max(20).optional() }))
    .mutation(async ({ input, ctx }) => { const { id, ...data } = input; await updateProposal(id, data); await audit('proposals', id, 'update', ctx.user?.id); return { success: true }; }),
      checkEditor(ctx);

  delete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { await deleteProposal(input.id); await audit('proposals', input.id, 'delete', ctx.user?.id); return { success: true }; }),
    checkEditor(ctx);

  sendProposal: protectedProcedure
    .input(z.object({ proposalId: z.number(), recipientEmail: z.string().email().max(320), message: z.string().max(2000).optional() }))
    .mutation(async ({ input, ctx }) => {
      checkEditor(ctx);
      const proposal = await getProposalById(input.proposalId);
      if (!proposal) throw new Error('Proposal not found');
      const client = await getClientById(proposal.clientId);
      await notifyOwner({ title: `Proposal Sent: ${proposal.title}`, content: `Sent to: ${input.recipientEmail}\nClient: ${client?.companyName || 'Unknown'}` });
      await updateProposal(input.proposalId, { status: 'sent' });
      return { success: true };
    }),

  acceptances: protectedProcedure.input(z.object({ proposalId: z.number().int().positive() })).query(async ({ input }) => getProposalAcceptances(input.proposalId)),
});
