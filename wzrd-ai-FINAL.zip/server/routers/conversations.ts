/**
 * AI Conversations Router — list, get, update conversations.
 */
import { protectedProcedure, router } from "../_core/trpc";
import { checkEditor } from "../_core/authorization";
import { z } from "zod";
import { getAiConversationsByProject, getAiConversationById, updateAiConversation } from "../db";

export const conversationsRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number().int().positive().optional() }).optional())
    .query(async ({ input }) => {
      if (input?.projectId) return getAiConversationsByProject(input.projectId);
      return [];
    }),
  getById: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ input }) => getAiConversationById(input.id)),
  update: protectedProcedure
    .input(z.object({ id: z.number().int().positive(), title: z.string().max(500).optional() }))
    .mutation(async ({ input, ctx }) => { const { id, ...data } = input; await updateAiConversation(id, data); return { success: true }; }),
      checkEditor(ctx);
});
